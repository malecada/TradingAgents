"""Exclusive current-owner per-graph MCM publication; no reuse/empirical release."""
import importlib.util
import io
import os
from pathlib import Path
import numpy as np
from tradingagents.research.onchain_replication.provenance import canonical_bytes,file_hash,thaw,durable_mkdir,sync_directory

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3]
spec=importlib.util.spec_from_file_location('mcm_publication_driver',HERE/'driver.py')
driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
producer=driver.artifacts.producer;reader=driver.artifacts.publication.reader
SOURCES=tuple(sorted(set(driver.SOURCES)|{str(Path(__file__).relative_to(ROOT))}))

def require(value,message):
    if not value:raise ValueError(message)
def equal(a,b):return canonical_bytes(a)==canonical_bytes(b)

def encoded_size(matrix,binding):
    """Exact numeric-only component sizes for one native float32 MCM matrix."""
    require(isinstance(matrix,np.ndarray) and matrix.dtype==np.dtype('float32')
        and matrix.ndim==2 and all(n>0 for n in matrix.shape),'native nonempty float32 MCM matrix required')
    header=io.BytesIO()
    np.lib.format.write_array_header_1_0(header,np.lib.format.header_data_from_array_1_0(matrix))
    array_bytes=len(header.getvalue())+matrix.nbytes
    member='array-000000.npy'
    manifest={'schema_version':1,'context':binding,'tree':{'kind':'array','member':member},
        'arrays':{member:{'sha256':'0'*64,'bytes':array_bytes,'shape':list(matrix.shape),'dtype':str(matrix.dtype)}}}
    size=len(canonical_bytes(manifest))
    return size,size+array_bytes,matrix.nbytes

def attempt_directory(owned,graph_hash):
    require(driver.artifacts.publication.driver.proof.valid_hash(graph_hash),'exact graph hash required')
    bound=owned.workload.bound
    return bound._run.admission.root/'research_artifacts/onchain_mcm_workflows'/bound.record['workflow_identity']/bound.record['experiment']/graph_hash

def produce(owned,journal,*,graph_hash,sampler_input,artifact_input,dictionary_output_input,
            dictionary_proof_sha256,mcm_input,output_input):
    require(type(owned) is driver.artifacts.producer.artifacts.consumer.ownership.OwnedJournal
        and type(journal) is driver.artifacts.producer.artifacts.feature_journal.FeatureJournal,'actual MCM owner/journal required')
    route=owned.workload;bound=route.bound;bound.check();owned.lease()
    require(bound._ancestry_arguments is None,'historical MCM publication requires separate admission')
    ad=bound._run.admission;owner=thaw(bound.record);directory=Path(owner['journal_directory'])
    require(type(graph_hash) is str and graph_hash in route.descriptor['required_graphs'] and graph_hash in route._graphs,'required MCM graph membership differs')
    graph=route._graphs[graph_hash];n=len(graph.node_ids);k=route.settings['size'];numeric=4*n*k
    require(n>0 and k>0 and n*k<=route.control['max_entries'],'MCM output entry allowance exceeded')
    attempt=attempt_directory(owned,graph_hash);metadata=producer.Metadata(ad.root);written={};published=False
    receipt_lease=None;component_state=None;prefix=thaw(journal.records);index=len(prefix)
    expected_owner={key:owner[key] for key in ('experiment','source_commit','producer','workflow_identity')}
    def sources():
        for name in SOURCES:
            sha=ad.experiment['source_files'].get(name)
            require(sha is not None and file_hash(ROOT/name)==sha and file_hash(ad.root/name)==sha,'MCM publication source differs')
    sources()
    def registered(name):
        require(type(name) is str and name in ad.inputs,'registered MCM publication input required')
        info=ad.inputs[name];return metadata.read(ad.root/info['path'],info['sha256'])
    claim=metadata.read(directory/'claim.json');plan=registered(claim['plan_input']);job=registered('execution_job')
    item=plan.get('producers',{}).get(owner['producer']);selected=job.get('payload',{}).get('representation_jobs',{}).get(owner['representation'])
    require(isinstance(item,dict) and isinstance(selected,dict)
        and item.get('mcm_output_input')==selected.get('mcm_output_input')==output_input,'MCM output route differs')
    policy=registered(output_input)
    require(isinstance(policy,dict) and set(policy)=={'schema_version','max_metadata_bytes','max_manifest_bytes',
        'max_artifact_bytes','max_attempt_bytes','max_array_bytes'}
        and type(policy['schema_version']) is int and policy['schema_version']==1
        and all(type(policy[key]) is int and policy[key]>0 for key in policy if key!='schema_version')
        and max(policy['max_metadata_bytes'],policy['max_manifest_bytes'])<=reader.MANIFEST_LIMIT,'MCM output policy differs')
    cap=policy['max_metadata_bytes'];reserved=4*cap+policy['max_artifact_bytes']
    require(reserved<=policy['max_attempt_bytes'] and numeric<=policy['max_array_bytes'],'MCM publication allowance exceeded')
    sample_policy=registered(artifact_input)
    require(type(sample_policy.get('max_journal_events')) is int and 2<=index<sample_policy['max_journal_events'],
        'MCM event allowance exceeded before computation')
    require(not any(e['stage'] in ('mcm_progress','embedding_progress','graph_complete') and e['context'].get('graph_hash')==graph_hash for e in prefix),
        'graph already has numerical progress; explicit continuation needed')
    event_path=directory/f'event-{index:06d}.json';component=directory/f'checkpoint-{index:06d}/manifest.json'
    require(not event_path.exists() and not component.parent.exists(),'MCM event slot already reserved')
    for i,event in enumerate(prefix):
        require(equal(metadata.read(directory/f'event-{i:06d}.json',cap=sample_policy['max_manifest_bytes']),event),'MCM prior event differs')
    dictionary_path=driver.artifacts.publication.attempt_directory(owned)/'complete.json'
    dictionary_policy=registered(dictionary_output_input)
    require(driver.artifacts.publication.driver.proof.valid_hash(dictionary_proof_sha256),'explicit dictionary proof required')
    metadata.read(dictionary_path,dictionary_proof_sha256,dictionary_policy['max_metadata_bytes'])
    def lease():
        owned.lease();sources();metadata.lease()
        require(journal.directory==directory and equal(journal.owner,expected_owner)
            and journal.parent is None and not journal.sealed and journal.identity==owner['workflow_identity']
            and journal.required==sorted(route.descriptor['required_graphs'])
            and len(journal.records)==index+int(published) and equal(journal.records[:index],prefix),'MCM feature journal changed')
        if receipt_lease is not None:receipt_lease()
        if written:
            reader.inventory(attempt,set(written))
            for path,sha in written.items():metadata.read(path,sha,cap)
        owned.lease()
        if component_state is not None:
            signatures,files=component_state;reader.inventory(component.parent,files)
            for path,sig in signatures.items():require(path.resolve()==path and reader.signature(path.lstat())==sig,'published MCM component changed')
    lease()
    require(attempt.resolve()==attempt and attempt.is_relative_to(ad.root),'MCM attempt containment differs')
    durable_mkdir(attempt.parent);lease();attempt.mkdir(exist_ok=False);sync_directory(attempt.parent)
    require(attempt.stat().st_dev==ad.root.stat().st_dev,'MCM attempt device differs')
    def write(name,value):
        raw=canonical_bytes(value);require(len(raw)<=cap,'MCM metadata allowance exceeded')
        path=attempt/name
        with path.open('xb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
        sync_directory(attempt);sha=file_hash(path);written[path]=sha;metadata.read(path,sha,cap)
        return {'path':str(path),'sha256':sha}
    try:
        start=write('start.json',{'schema_version':1,'status':'reserved','owner':owner,'resumable':False,'graph_hash':graph_hash,
            'output_input':output_input,'output_policy_sha256':ad.inputs[output_input]['sha256'],
            'dictionary_proof':{'path':str(dictionary_path),'sha256':dictionary_proof_sha256},
            'mcm_input':mcm_input,'event_index':index,'sources':{name:ad.experiment['source_files'][name] for name in SOURCES},
            'reserved_encoded_bytes':reserved})
        result=driver.compute(owned,journal,graph_hash=graph_hash,sampler_input=sampler_input,artifact_input=artifact_input,
            output_input=dictionary_output_input,dictionary_proof_sha256=dictionary_proof_sha256,mcm_input=mcm_input)
        receipt_lease=result.pop('_lease');lease();matrix=result['mcm']
        require(matrix.shape==(n,k) and str(matrix.dtype)=='float32' and matrix.nbytes==numeric
            and result['completed_rows']==n and result['completed_cells']==n*k and result['output_bytes']==numeric
            and result['graph_hash']==graph_hash,'MCM complete output accounting differs')
        require(equal(result['dictionary_provenance']['dictionary_proof'],{'path':str(dictionary_path),'sha256':dictionary_proof_sha256}),
            'MCM dictionary provenance differs')
        context={'workflow_identity':owner['workflow_identity'],'graph_hash':graph_hash,'next_node':n,
            'node_order_sha256':result['node_order_sha256'],'ordered_motifs':result['ordered_motifs'],
            'dictionary_provenance':result['dictionary_provenance'],'workload_sha256':result['workload_sha256'],
            'mcm_policy':result['mcm_policy'],'pair_workload_sha256':route.descriptor['pair_workload']['sha256'],
            'completed_rows':n,'completed_cells':n*k,'output_input':output_input,'output_policy_sha256':ad.inputs[output_input]['sha256']}
        binding={'owner':expected_owner,'stage':'mcm_progress','context':context}
        template={'stage':'mcm_progress','context':context,'path':str(component.relative_to(directory)),'sha256':'0'*64,'binding':binding}
        event_bytes=len(producer.lifecycle._encode(template));manifest_bytes,encoded,actual_numeric=encoded_size(matrix,binding)
        require(actual_numeric==numeric and manifest_bytes<=policy['max_manifest_bytes'] and encoded<=policy['max_artifact_bytes']
            and event_bytes<=min(cap,policy['max_manifest_bytes'],sample_policy['max_manifest_bytes']),'MCM event/component allowance exceeded before write')
        lease();journal('mcm_progress',context,matrix);published=True;lease()
        event_sha=file_hash(event_path);event=metadata.read(event_path,event_sha,cap)
        require(equal(event,template|{'sha256':event['sha256']}) and equal(event,journal.records[index]),'MCM published event differs')
        _,signatures,_,files=reader.inspect_component(component,event['sha256'],binding,ad.root,
            policy['max_manifest_bytes'],policy['max_artifact_bytes'],policy['max_array_bytes'])
        component_state=(signatures,files)
        proof=write('complete.json',{'schema_version':1,'status':'complete','owner':owner,'resumable':False,'start':start,
            'graph_hash':graph_hash,'event_index':index,'output_input':output_input,'output_policy_sha256':ad.inputs[output_input]['sha256'],
            'node_order_sha256':result['node_order_sha256'],'ordered_motifs':result['ordered_motifs'],
            'dictionary_provenance':result['dictionary_provenance'],'workload_sha256':result['workload_sha256'],'mcm_policy':result['mcm_policy'],
            'completed_rows':n,'completed_cells':n*k,'array_bytes':numeric,'encoded_artifact_bytes':encoded,'encoded_event_bytes':event_bytes,
            'event':{'path':str(event_path),'sha256':event_sha},'component':{'path':str(component),'sha256':event['sha256']}})
        lease();return proof
    except BaseException as error:
        try:write('failed.json',{'schema_version':1,'status':'failed','owner':owner,'resumable':False,'graph_hash':graph_hash,
            'reason_type':type(error).__name__,'reason':str(error)[:500]})
        except BaseException:pass
        raise
