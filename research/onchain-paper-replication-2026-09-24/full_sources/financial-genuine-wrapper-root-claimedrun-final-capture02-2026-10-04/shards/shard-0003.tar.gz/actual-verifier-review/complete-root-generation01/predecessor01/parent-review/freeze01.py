import hashlib,json,os,stat
from pathlib import Path
O=Path(__file__).resolve().parent;x=json.loads((O/'READBACK01.json').read_text())
(O/'REPORT01.md').write_text('''# Independent claimed-run Parent source review

Accepted as source preparation only. The frozen candidate and every author manifest body/type/mode match. Reversing exactly the nine declared changes reproduces the entire preserved Parent source and AST. All six helpers are unchanged. The actual committed gate, all 338 selected source bodies, eight inputs and original admission/job/resource API bodies match the proposal. Source339/current=design0a2, wrapperf4ea, preserved failed predecessor and exact cumulative extension/review pins are required.

The new Parent retains genuine read-only job._admitted before any attempt directory, intent or spawned source child. Its required effective ceiling is19 while family base18/prior0 remains unchanged. This review never called admission, created a claim, installed the Parent, or imported research/numerical modules. Actual admission evidence and source/runtime proof must be bound separately. No refund, replay or checkpoint authority is inferred from copied failed history.

The real draft and every missing/null contract field refused. No fabricated valid release was constructed. The final review and actual source/input/runtime and full-recovery proof fields remain null. Root must supply authentic proof bodies and receive independent exact-contract review, then preserve/recover the complete final Source/Parent/review union before a fresh numerical release. The default CLI validates release only; --launch performs full preflight.

Independent controls used real owned opaque files, literal-symlink refusal, exact stream extent checks, actual descriptors and injected read/close failures. MemoryError, SystemExit and KeyboardInterrupt preserved their original object identity across a real descriptor close plus close-error; ordinary uncertainty stopped with CleanupFailure. Each descriptor was closed exactly once. Two real tiny subprocesses exercised unchanged supervisor success and fatal-on-spawn drainage, retaining original logs and cleanup records; both were reaped and no final group remained. These are source controls, not future native OS observations or capacity measurements.

The unchanged caller retains bounded streams, owned descendant cleanup, original null self-exit, separate Root exit responsibility, source-bound absent-dispatch checks, actual unit/cgroup cleanup and planned-interruption outcome review. Physical memory and disk predicates are future observations. Live Torch/CUDA/driver equality, installed runtime bodies, empirical stores, scientific success and numerical release are not established.

No actionable source defect was found in this bounded candidate review. The next admissible action is concrete Root composition with genuine proof references; it does not authorize dispatch. All original failures and old Parent/source remain immutable.
''')
m=[]
for p in sorted(O.rglob('*')):
 s=p.lstat();r={'path':p.relative_to(O).as_posix(),'mode':stat.S_IMODE(s.st_mode)}
 if stat.S_ISREG(s.st_mode):b=p.read_bytes();r.update(kind='file',bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 elif stat.S_ISDIR(s.st_mode):r['kind']='directory'
 elif stat.S_ISLNK(s.st_mode):r.update(kind='lexical-symlink',target=os.readlink(p))
 else:raise AssertionError(p)
 m.append(r)
(O/'MANIFEST01.json').write_text(json.dumps({'schema_version':1,'members':m},sort_keys=True,indent=2)+'\n')
print('checks',x['checks'])
for n in ['READBACK01.json','REPORT01.md','MANIFEST01.json']:print(n,hashlib.sha256((O/n).read_bytes()).hexdigest())
