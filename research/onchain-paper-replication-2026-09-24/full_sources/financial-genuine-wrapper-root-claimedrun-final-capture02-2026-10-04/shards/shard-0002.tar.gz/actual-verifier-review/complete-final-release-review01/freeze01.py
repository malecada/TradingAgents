import hashlib,json,stat
from pathlib import Path
O=Path(__file__).resolve().parent;x=json.loads((O/'READBACK01.json').read_text())
(O/'REPORT01.md').write_text('''# Exact claimed-run Parent contract review

Accepted the exact actual proposalec75df7b for caller5d5cbdae and current=design0a2. RELEASE01.json is the genuine seven-field independent contract result required by parent.validate_release. It binds the complete proposal except final_review and the three genuine proof bodies:3268 cumulative,0592 actual source/input/runtime metadata admission and468d actual complete Source339 archival recovery. Every installed0600 proof copy equals its authenticated original; raw originals and the reviewed proposal are retained here. No Root or Parent file was changed.

The installed caller and all six helpers equal the accepted source preparation and independent034d review. All338 current source bodies/eight inputs/current3a20 gate join. Actual interpreter/lock and all251 pinned RECORD files match their metadata hashes. This is not a numerical Torch/CUDA/driver observation or installed package-body recovery. Current Source remains identical to its already accepted full1,029-member Source339 archive; the complete actual recovery proof and original independent manifest0a4c remain bound.

Actual metadata admission reported effective19, while family base18/prior0 and one globally spent claim/highest actual claim ceiling18 remain explicit. Original claim4c54/failed3515 is unchanged, with no COMPLETE, replacement or new claim. The fixed new classification/eager/interrupt1 identity, eight inputs, wall1800,3 GiB native memory high=max/reserve,6 GiB startup reserve,4 MiB file limit and whole-Source storage/disk watch metadata are pinned. Actual Parent attempt/native output/claim namespaces are absent. No fresh admission, preflight or launch was called by this review.

Pure validator controls refuse the original null-final-review proposal and every missing field. After authentic real release creation, the original pure validator accepts only the exact contract; old spent identity, old source, changed phase/caller, substituted cumulative proof, an unregistered refund field or missing recovery proof refuse. This proves exact contract binding, not a synthetic successful OS or scientific outcome. Original planned interruption/failure semantics, null Parent self-exit and separate Root outcome responsibility remain unchanged.

This release is a necessary contract review, not numerical eligibility. Root must next bind only this genuine release, preserve the complete final Parent/caller/generated verifier and full original review witnesses, obtain actual external plus fresh recovery and independent final-union acceptance, and perform fresh genuine preflight before any separately authorized one-use dispatch. Source-only release does not establish full caller recovery, runtime bodies, empirical stores, resource capacity or paper-fit authority. Every original failed/spent identity and immutable receipt remains preserved.
''')
m=[]
for p in sorted(O.rglob('*')):
 s=p.lstat();assert stat.S_ISREG(s.st_mode);b=p.read_bytes();m.append({'path':p.relative_to(O).as_posix(),'kind':'file','mode':stat.S_IMODE(s.st_mode),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(O/'MANIFEST01.json').write_text(json.dumps({'schema_version':1,'members':m},sort_keys=True,indent=2)+'\n');print('checks',x['checks'])
for n in ['RELEASE01.json','READBACK01.json','REPORT01.md','MANIFEST01.json']:print(n,hashlib.sha256((O/n).read_bytes()).hexdigest())
