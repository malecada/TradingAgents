# Current state — representative Ethereum real-data pilot

Current 2026-10-11: goal ACTIVE and incomplete. Pilot31 (`eth-paper-real-data-end-to-end-resource-20261011-31`) ran ONCE and permanently FAILED. Actual Root session64419 exited1 (tool4bac07); native child exited1. All five original PIDs and the cgroup are absent; retained unit is failed/MainPID0/emptyControlGroup. Source freeze ended after terminal cleanup. No native numerical job is active. Never relaunch31.

The new failure is `ValueError: import lease: loaded module/function identity changed`, at compact_mcm_batched.py:508, the SECOND added lease boundary after `_modules`; the first at501 passed. Source investigation attributes the change to selected compiled helpers imported after the immutable loaded-module baseline. The specific changed object was not recorded in the raw receipt. The earlier stale-timer failure did not recur. The proposed narrow correction preloads only the selected compiled helpers before lease activation, retaining authentication, all three boundaries and the60second deadline. Candidate checks/review/integration are pending; no scientific-method change is admitted.

Actual elapsed1013.937068334seconds; sampled memory peak5368631296bytes, last observed kernel peak5370859520bytes, OOM0/max0. Sampled storage peaks5578678059logical/5157453824allocated bytes. These are preparation-prefix measurements, not whole-feature or training capacity. Original dictionary import completed without historical recomputation. ZERO whole MCM, ZERO real joint updates and ZERO financial fits. Original32motifs/512spent samples/sevenWHOLEgraphs/415968128cells/model20f451/trainingd527 remain fixed.

Accounting:71closed=33COMPLETE+38FAILED; highest adopted102. No active claim or new103 amendment. Preserve failed-worker versus unavailable-outer dispositions, original nulls and spent identities; no refund, transfer or cap ladder. Broader13tasks/C01–C18 and1420paper fits remain pending; broader heartbeat is paused in favor of the pilot.

Main and last actual remote readback HEAD5cda5d948e401ffd03b1a4ed0baa65f06d5783f9. Public preparation increment20 was actually recovered and independently acceptedb56b3603:227files31directories/6809600archive bytes, sourcecommit6b09d7b5b8c61d07e0970d65d3ccdf9e85836ef1. Failed31 outcome21 tooling is source acceptede7a325ca; actual selection/capture/push/fresh recovery remains pending. Terminal review46ed6dfa accepted the failed disposition; its boundary locator requires a narrow correction before final use. Existing private dispatch, installed package bodies and unchanged scientific/raw stores are outside this incremental recovery scope. No deletion authority follows.

Root owns live integration/Git, registrations/accounting, STATE, actual preservation/recovery and ONE native launcher. Bounded owners: pilot29_prior_throughput owns NEW pilot31-loaded-identity-correction01; outcome16_release_review owns NEW pilot31-terminal-outcome-review01 and its locator correction; compiled_normalization_connection owns NEW pilot31-outcome-increment-tools-review01 and subsequent actual-return verification. No live source integration before actual failed31 review and recovery.

Next safe action: finish the focused preload correction while Root captures and freshly recovers the reviewed failed31 increment; independently verify actual returned bytes. Then review/integrate the changed source seam and prepare ONE fresh32 identity with exact committed registration/cumulative allowance before empirical execution. Reuse accepted evidence and tooling. Retain16GB physical ceiling,10GiB disk floor and frozen job limits (native5GiBhigh/6GiBmax/swap0/twoCPUs/8h/2.5GiBhostreserve/1GiBfile).

Evidence:

- [Actual31 terminal operation](full_sources/real-data-pilot-full31-entry-preparation02-2026-10-11/ROOT_TERMINAL_OPERATION01.json).
- [Actual31 terminal review](full_sources/pilot31-terminal-outcome-review01-2026-10-11/REVIEW01.json); locator correction pending.
- [Outcome21 tools review](full_sources/pilot31-outcome-increment-tools-review01-2026-10-11/TOOLS_REVIEW01.json).
- [Reviewed102 proposal](full_sources/pilot31-cumulative-machine-review01-2026-10-11/EXTENSION102_REVIEW01.json).
- [Prior checkpoints, exact preserved bytes](full_sources/state-consolidation-2026-10-11/STATE_THROUGH_PILOT30_FAILED.md). Consult only for a specific unresolved question.
