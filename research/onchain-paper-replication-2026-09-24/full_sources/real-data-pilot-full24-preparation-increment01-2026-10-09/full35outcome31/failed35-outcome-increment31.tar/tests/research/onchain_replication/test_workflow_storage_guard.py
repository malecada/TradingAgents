"""New storage boundary tests; kernel unit behavior is isolated by the existing mock."""
import json
from pathlib import Path
from tests.research.onchain_replication.test_resources import mock_unit
from tradingagents.research.onchain_replication import resources as guard

def budget(tmp_path):
    root=tmp_path/'outputs';root.mkdir()
    return {'root':str(root),'limits':{'max_allocated_bytes':1024*1024,'max_logical_bytes':8192,'max_entries':100,'max_depth':8,'max_scan_seconds':1}}

def test_storage_startup_refusal_never_dispatches(tmp_path,monkeypatch):
    policy=budget(tmp_path);(Path(policy['root'])/'huge').write_bytes(b'x'*9000)
    monkeypatch.setattr(guard.subprocess,'run',lambda *a,**k:(_ for _ in ()).throw(AssertionError('dispatched')))
    result=guard.guarded_run(['true'],cwd=tmp_path,receipt_dir=tmp_path/'r',storage_budget=policy)
    assert result['phase']=='failed' and 'storage logical' in result['limit_reason']
    assert result['storage_breach']['logical_file_bytes']==9000
    assert not (tmp_path/'r/release.json').exists()

def test_storage_runtime_breach_stops_owned_unit(tmp_path,monkeypatch):
    receipt,calls=mock_unit(tmp_path,monkeypatch,completed=True);policy=budget(tmp_path);atomic=guard._atomic
    def write(path,value):
        atomic(path,value)
        if path.name=='release.json':(Path(policy['root'])/'overflow').write_bytes(b'a'*9000)
    monkeypatch.setattr(guard,'_atomic',write)
    result=guard.guarded_run(['true'],cwd=tmp_path,receipt_dir=receipt,storage_budget=policy)
    assert result['phase']=='failed' and result['cleanup_verified']
    assert 'storage logical' in result['limit_reason'] and result['storage_breach']['logical_file_bytes']==9000
    assert any('stop' in c for c in calls)
    assert json.loads((receipt/'final.json').read_text())==result

def test_valid_storage_policy_and_terminal_observation(tmp_path,monkeypatch):
    receipt,calls=mock_unit(tmp_path,monkeypatch,completed=True);policy=budget(tmp_path)
    (Path(policy['root'])/'value').write_bytes(b'abc')
    result=guard.guarded_run(['true'],cwd=tmp_path,receipt_dir=receipt,storage_budget=policy)
    assert result['phase']=='complete' and result['storage_budget']==policy
    assert result['storage_observation']['logical_file_bytes']==3
    assert result['storage_peak_logical_file_bytes']==3

def test_registered_storage_policy_accepts_owned_scope(tmp_path):
    from tradingagents.research.onchain_replication.job import resource_policy
    from tests.research.onchain_replication.test_job import policy
    value={**policy(tmp_path),'storage_budget':budget(tmp_path)}
    assert resource_policy(value,tmp_path)==value

def test_registered_storage_policy_rejects_foreign_or_invalid_scope(tmp_path):
    import pytest
    from tradingagents.research.onchain_replication.job import resource_policy
    from tests.research.onchain_replication.test_job import policy
    nested=tmp_path/'owned';nested.mkdir();value={**policy(nested),'storage_budget':budget(tmp_path)}
    with pytest.raises(ValueError,match='storage'):resource_policy(value,nested)
    value={**policy(tmp_path),'storage_budget':{'root':str(tmp_path),'limits':{'max_entries':True}}}
    with pytest.raises(ValueError,match='storage'):resource_policy(value,tmp_path)


def test_subdomain_observer_failure_closes_descriptors(tmp_path,monkeypatch):
    from tradingagents.research.onchain_replication import workflow_storage as storage
    import os
    policy=budget(tmp_path);closed=[];real_close=os.close
    def close(fd):closed.append(fd);real_close(fd)
    class Refusal:
        def account(self,*args):raise ValueError('subdomain refused')
    monkeypatch.setattr(storage.os,'close',close)
    watch=storage.StorageWatch(Path(policy['root']),policy['limits'],_subdomain_factory=Refusal)
    import pytest
    with pytest.raises(ValueError,match='subdomain refused'):watch.check()
    assert len(closed)==1
