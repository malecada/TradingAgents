"""Explicit registered engineering source edge; never checkpoint provenance rewriting.
No numerical imports or tensor decoding. Runtime calls require original active Run.
"""
import hashlib,json,os,stat,time
from pathlib import Path,PurePosixPath

CONTROL_TARGETS={'tradingagents/research/onchain_replication/financial_wrapper_fixture.py': '5f478bc3570aab21ffdfa32e1215aeddbf085e5d33a3da3a8131cfb0c4aff655', 'tradingagents/research/onchain_replication/training.py': '6f278f5b0538928827f2be06be5e8b358c5c6fcf2761085ff58b73832a74da00', 'tradingagents/research/onchain_replication/workflow_storage.py': '91e21c525a156cc8c25877ac35f0308896a1a0d1e6279d5aecf91d7e02567780'}
FAMILY='synthetic-financial-wrapper'
HISTORICAL_CHECKPOINT_SHA256='b2f7d33b2f2280f5d9b0a9731ea320c64d18768bda772926421ddb0af2e12c70'
HISTORICAL_CLAIM_SHA256='d390980c956aab64d5521698cbb6123ccf01ece94a95277b97755f019adf692b'
HISTORICAL_FAILED_SHA256='4b2d7b0d162e80fe2074997baed35f2d6e6c86e5f660872fc2b8e97bb9622558'
HISTORICAL_ID='financial-wrapper-classification-eager-interrupt1-claimedrun-20261004-01'
HISTORICAL_PROTOCOL_SHA256='1267f9c5dff20cfd542f7d0c70b3f4b1ece98cfa4dd8f6c27a3b7c2d224ef8db'
HISTORICAL_SOURCE='0a2e7639b42b9423b90743feadcda4078aa21816'
HISTORICAL_STATE_SHA256='223ced42edec29ec0afd4ea5265b2e0a557a98787e57be47e841e8491511a281'
MODEL='20f451c08143dd81491b5c9fa0a90243ee6a9363df1fbbfcbd9c45b32f9b054d'
OLD_MAP={'fixture_tools/capsule_builder01.py': '8b522ecdefe0a1cd04be7586e07538aed1f9ba883a773ad7fe8de28065ff107d', 'fixture_tools/controller01.py': '87d64a8ad54d687e4438c0421567f16e90612463182b294fd4610f152f18a743', 'fixture_tools/generate_inputs01.py': 'a5569e4d0a6914443f36f2c96a319b26110f8dcb379e41f4bafbd92d789c9b98', 'fixture_tools/outer_controller01.py': '93a7b8bc57d3733018045e4d6743cc2fb6c0da0143b7f6be05d3f39ce08b7ca5', 'fixture_tools/raw_receipts01.py': '47e025bb5e6c1a442ab8c03d9d19d95d6f9f5541377f8c7e753584dbfa2077b4', 'fixture_tools/runtime_gate01.py': '8a60c8746d3d54e609f96c09e2560741ed8edfd32426279ee92068e7b13d5cdc', 'proof_tools/build_release_draft01.py': '68beeb7179d02268332cf8102a1f010c4059aa26b7086f1829922fa720d2d4f0', 'proof_tools/proof_outer01.py': '1ba69376298e19843dc6721b5a4ac204aff34fc6156bc60a2318d7f3e02b3aa1', 'proof_tools/proof_raw01.py': '19cee43d920881c08065913373079c96fe261c3f46692c438a022377a211406d', 'proof_tools/proof_release01.py': '53c2294b7b38f340e9160e4484a6b7506942ce36e2dff12694a47f9b72206812', 'proof_tools/proof_supervise01.py': 'e0c8c13c4502faba07e226d4e82329c4c6677d57a8324d44d8094233512f67de', 'proof_tools/runtime_gate01.py': '8a60c8746d3d54e609f96c09e2560741ed8edfd32426279ee92068e7b13d5cdc', 'research/onchain-paper-replication-2026-09-24/full_sources/dictionary-artifact-route-2026-10-01/route.py': '1d98c4bec261ced5a5ed7357aabe6c8b27a26b2edbb07380d3fbbd2e870fffad', 'research/onchain-paper-replication-2026-09-24/full_sources/dictionary-publication-2026-10-01/driver.py': '487da65650c7905a8c27fd7adab76084aa572f800959299077e034918a0e55aa', 'research/onchain-paper-replication-2026-09-24/full_sources/dictionary-publication-2026-10-01/publication.py': '95ccbaa8224a48848618c9ff63a428586a441337c4377a1d428d1d01e9d4fdea', 'research/onchain-paper-replication-2026-09-24/full_sources/graph-feature-artifact-route-2026-10-01/route.py': 'e7d34cb08a457b402d28d75dcb1a804579c6b1bf8a9b9bd68d56c695d8004806', 'research/onchain-paper-replication-2026-09-24/full_sources/graph-feature-boundary-2026-10-01/boundary.py': '792deafa7270a686c923dcd2f6b26bf16de14d1a86608bda620c608d1e4c20c5', 'research/onchain-paper-replication-2026-09-24/full_sources/graph-feature-publication-2026-10-01/encoded_hashes.py': '302922b0c403817ccbb6665942ca9d28950a6fe13a8bb41fcc9a744ee77d6f2b', 'research/onchain-paper-replication-2026-09-24/full_sources/graph-feature-publication-2026-10-01/publication.py': 'e0ce2673fcca7d7fdb544ac3ed113b09e3d116fd44750ab1292eaf56028284da', 'research/onchain-paper-replication-2026-09-24/full_sources/graph-feature-route-2026-10-01/route.py': 'e9908a3687823af56c5088f7e377c58f89632eb1d8d1efc7ba3f25430f3eced5', 'research/onchain-paper-replication-2026-09-24/full_sources/mcm-array-kernel-2026-10-01/kernel.py': '4a870113be59f55913ffb91ee79c89438f3a43b53de280fa049467a1781fa047', 'research/onchain-paper-replication-2026-09-24/full_sources/mcm-artifact-route-2026-10-01/route.py': '88482b62d4bdb86ea9fabba2da0b4e36955084c03866766d16300d98da508070', 'research/onchain-paper-replication-2026-09-24/full_sources/mcm-publication-2026-10-01/driver.py': 'd76d2c01777c6f71c6a6295a55b94da82d3bd699f30d44102fc4b5c22c9bac75', 'research/onchain-paper-replication-2026-09-24/full_sources/mcm-publication-2026-10-01/publication.py': 'f76fc7ec93eb0cefb886d32fe301a09c28fb4ae447b268b0077bfc21017f87d6', 'research/onchain-paper-replication-2026-09-24/full_sources/original-import-fixture-bridge-candidate-2026-10-02/imported_kernel.py': '8d810af1448893858504a90537a0a76b6ba70306427d3385f9571b0677a99287', 'research/onchain-paper-replication-2026-09-24/full_sources/pair-component-reader-2026-10-01/reader.py': '3f9ebf731b5027f3282e8d4c7ae8a66c8d25f4aa8a989e2a8cfbd44d3d27cc50', 'research/onchain-paper-replication-2026-09-24/full_sources/pair-consumer-route-2026-10-01/route.py': '0e8e2e34fcd1a98660f7dbe6aa7ebd0ebf94fb8ff6a3e555c0d44f5ad8799da0', 'research/onchain-paper-replication-2026-09-24/full_sources/pair-extent-2026-09-30/extent.py': 'c62c743c67490e37b9aca2e6722d143e02df009c5398bb2fd246e9051f1ac3ac', 'research/onchain-paper-replication-2026-09-24/full_sources/pair-owner-route-2026-09-30/journal.py': 'e51d087c49651e12867dc6297d366d5839cc675923839be75193c37e2bb03421', 'research/onchain-paper-replication-2026-09-24/full_sources/pair-owner-route-2026-09-30/ownership.py': '43198ef10c3cc5f9b457edc5d37a9c1bcf1e34deb603d973ced2cd788d3508bb', 'research/onchain-paper-replication-2026-09-24/full_sources/pair-serial-composition-2026-09-30/serial.py': 'c23d2d709385de7a9d241ea48d993655785c7304c9e542e8e565765a698970ee', 'research/onchain-paper-replication-2026-09-24/full_sources/pair-workload-2026-09-30/workload.py': '30a957ad48997a3236203e1af2ccf9e0874b172ffac73773c31efc6bece9fc67', 'research/onchain-paper-replication-2026-09-24/full_sources/pair-workload-route-2026-09-30/route.py': 'a71d890fae6681c29bd2a4b49241068fbf1936001bc4392880025ca1fd2f668c', 'research/onchain-paper-replication-2026-09-24/full_sources/representation-closure-route-2026-10-01/closure.py': 'c56bcb63f8ca3b412b50b24e14638c20ea2a133da744ad973bc20981f282e301', 'research/onchain-paper-replication-2026-09-24/full_sources/representation-denominator-2026-10-01/denominator.py': 'e3ffddacc03011fb6e1b5f446c6820ac491a6e7b84c8ffef01b7f507530c1bd8', 'research/onchain-paper-replication-2026-09-24/full_sources/representation-denominator-route-2026-10-01/route.py': '3671b1c9efc042e55fdd2b2807f955d01317bc9cd5844b77b7a4e19b699eba56', 'research/onchain-paper-replication-2026-09-24/full_sources/representation-seal-2026-10-01/publication.py': 'd621f59f18e368badce7a60779c7c801502af231fe5c483171c80a28ed78392c', 'research/onchain-paper-replication-2026-09-24/full_sources/representation-seal-2026-10-01/records.py': '85dcf606ca0fc97ea4cfa3974cebccbe3f1f3fd1aae0b3af1134900e58ead6ee', 'research/onchain-paper-replication-2026-09-24/full_sources/sample-artifact-route-2026-10-01/route.py': 'e049307f0acd01e4646cba2d7b7e79d4f634db058faafe87e0591c986ffea7d3', 'research/onchain-paper-replication-2026-09-24/full_sources/sampler-leased-core-2026-10-01/core.py': '07428fc777ec7224f199d245aee10658b8f4e74520732f6c85dcc7d8d2a37bc6', 'research/onchain-paper-replication-2026-09-24/full_sources/sampler-proof-route-2026-10-01/producer.py': 'f5703eea849b94707c750695f1bdd97512ed428e39033b013420043568762305', 'research/onchain-paper-replication-2026-09-24/full_sources/sampler-proof-route-2026-10-01/route.py': 'e7d7db3a20bf37da88047a12ea1e90a66c848f066b5078caaac41478a414d1be', 'research/onchain-paper-replication-2026-09-24/full_sources/terminal-output-lifetime-2026-10-01/native_map.py': '0462c2eb5cb8991b35e631b1ea45669afd70f9df97656cd4d8ec1e2abfcb7ef7', 'research/onchain-paper-replication-2026-09-24/full_sources/terminal-output-lifetime-2026-10-01/outputs.py': 'a0d44a625cebf30060764c2515f23dae150671c2ade221a11c17ec91d533d727', 'research/onchain-paper-replication-2026-09-24/full_sources/terminal-output-lifetime-2026-10-01/seal.py': 'a85fe1fa35859acbf948162e60e45cb33e6e76aaedb7532340eacd902c52d1ec', 'tradingagents/__init__.py': 'f3f6f89f20f49a016e061266fa802b73fa95720d060a2642573d4227646ad4e5', 'tradingagents/research/__init__.py': 'b34ced6fb4b6dd9dc1ae15645c40d62687ae7fa85f104ff77a6f1f49f874d2af', 'tradingagents/research/__main__.py': 'd5d7664ed30f9905a4911c70d69a756e5260e534365d68968808d4f5079cd70e', 'tradingagents/research/admission.py': '585d66f526d88f8488c6efcc4989a09328006e393566a596fe9e95c6c7f60cfd', 'tradingagents/research/budget_extensions.py': '59d22880e9ff7909508db6b0c15a7a833df30be365af4e31d643ed64afabb25a', 'tradingagents/research/examples.py': '0c4e4e901d14455b6742627a3c0bd42ffe65f5cf8eea7b64afbd0010dcbcbdc1', 'tradingagents/research/lifecycle.py': '88589c2dab53954711a66a22f2bf7e134a6e7d21072c5b7b508d11f04c6490dc', 'tradingagents/research/onchain_replication/__init__.py': '905f63046b02552c4d7cd90014328a48d77bcdb336b4a1f3351b453b83878fd1', 'tradingagents/research/onchain_replication/aggregation.py': '768c2ca743b2146fcc6bf606e4fa0bf41273ac15d06344d3a25a6aac78e8038f', 'tradingagents/research/onchain_replication/archive_chunks.py': 'f26f1cb62334497494f9b02579f53be9e2238889a81f56c04fd4e781542b38fe', 'tradingagents/research/onchain_replication/archive_consume.py': '9cfa242b77e42c2385e3c4cb8e51086965cc7d42768f2c52364fa3fd4ec77dc5', 'tradingagents/research/onchain_replication/archive_dispatch.py': '05eafe349dfafefe0b17ed8b8efaa3a480eff0f943988212846cabcec414f953', 'tradingagents/research/onchain_replication/archive_owner_operations.py': '5882578d065e94af588511356071b8f575aa1e8a1bbd7a9ab116e5853eb4c83f', 'tradingagents/research/onchain_replication/archive_owner_policy.py': '81b0e2fa4220c45461ffad850209e92819b65a56a7037887d1d7ba92c97956c9', 'tradingagents/research/onchain_replication/archive_owner_seal.py': '7c8c01ce43756605e4765f8e04e1cbbf1665d651d076b36eab74340acb0b07fa', 'tradingagents/research/onchain_replication/archive_owner_stage.py': '21a1f134c4ed0d4f57c266f21d4dd130d61241117b11e7f66a6466db3ddec39c', 'tradingagents/research/onchain_replication/archive_owner_writer.py': '7980139206c4b2a0e8b11763f44d23a73c4e9f067d9c10799a081664c42135d1', 'tradingagents/research/onchain_replication/archive_pair_reader.py': '11aedf0b9e5e8698831854952033f36db185c0cb4948f226912731ffc68d16df', 'tradingagents/research/onchain_replication/archive_pair_writer.py': 'c714c350f372be1b4e3c7840b5187deb7f72ee80549edfed4e48450e2d0ca052', 'tradingagents/research/onchain_replication/archive_transport.py': 'ef0fdc052a354af5b83e487cbc2d2cf92170149d64f90117adcb5ee37e3b572d', 'tradingagents/research/onchain_replication/archived_pair_log.py': 'e01d267c54be8bc786478d5647c90505f75f66dd96e1d57349ba3f76e6259b3f', 'tradingagents/research/onchain_replication/archived_stage.py': '1e4b09210a0a9384b778a71e1573298cb923711bcf7c7dcd3b464460001dc407', 'tradingagents/research/onchain_replication/array_neighborhoods.py': '4130af3869fb6615ba0898c5b25f1297f236e2df6b4dbe37d705dc2459982d6d', 'tradingagents/research/onchain_replication/baselines.py': '8ad95719b412aa633607f966e72e3246cceeceffb68e6ced90b4289637b3954a', 'tradingagents/research/onchain_replication/btc.py': '775838b3fc00534849d747f38c942f13187762b81c35ef5b1af52d67882a2dd0', 'tradingagents/research/onchain_replication/btc_source.py': 'deb5f4003ab63a69f945756f1e40fdd6212733331b2ef0133bab2ba0f69acead', 'tradingagents/research/onchain_replication/btc_store.py': '79f78d1bfc46d3e975f506407f3fcea102835235b5aa5b68cf6b1d7674c10452', 'tradingagents/research/onchain_replication/btc_subsets.py': '79f1cc4de5b5bf52e491201d05941bbe0ff29555d814f343294411f4591ed736', 'tradingagents/research/onchain_replication/btc_weekly.py': '6d52650e2bc6225c73da9841e51ab03be33ba8f3dd32a5ae504d6b76908c4aed', 'tradingagents/research/onchain_replication/cache.py': '5fbbe0df14cfc1802dd1df4da6c8bdbd1153a9fcbb4c89dd202e791d1811ddba', 'tradingagents/research/onchain_replication/calendar.py': 'c96e984a7d3482500a3a98231d859da1678cae4ca63960f33515a06dbda760f2', 'tradingagents/research/onchain_replication/cells.py': '1a15e33377030b6f3c533fd498bf75825778a59c35f2b0b8702cfaf79bb9bcfd', 'tradingagents/research/onchain_replication/census_production.py': '37ec0a081edaf2928146fab3984e362f1241809af43009eb05de307f247665b1', 'tradingagents/research/onchain_replication/checkpoints.py': '5bd40b1e573bad25807d8596472b437fee93eb7c644bc03e4cd45512e74437f0', 'tradingagents/research/onchain_replication/coinmetrics_prices.py': '5e14eae6fafccdfe562ab07c73ac3854f5e86751d74e468807b82be0a3a0a62f', 'tradingagents/research/onchain_replication/cold_files.py': '3740b149a69ed10448ae0d4f177f8d93c3300765b9e20846d4cbda5aec75ca85', 'tradingagents/research/onchain_replication/compact_closure.py': '87a145ec3ad7b44ce5a4e40ba2f610d8d8f4d715b1e70b767cece835abf9390e', 'tradingagents/research/onchain_replication/compact_cold_features.py': '9231e784a2085cbe4130568d748cbacb63d61e41fc955f3f0685831853ebd2c0', 'tradingagents/research/onchain_replication/compact_cold_proof.py': 'd3e401618b214647d27387d18182153ab493e69177394823e483546b44a6a153', 'tradingagents/research/onchain_replication/compact_cold_proof_inputs.py': 'cae64e3531207a9c3d62031a6e0969af72a0b0f8eb93814e643bfbe16ad8c42a', 'tradingagents/research/onchain_replication/compact_cold_proof_native.py': 'efbda343637395a88d6349aacbb77421430d59bbad745a375aad989b107e0aba', 'tradingagents/research/onchain_replication/compact_denominator.py': '6579c4aa57804ecfd35010beb81df0e81f722285bea9fda856d1a7f8e466b372', 'tradingagents/research/onchain_replication/compact_dictionary.py': '1c2618cc3706f4bdbfaba0ec957e1fb908f63857403bbdcc9341181effe313dc', 'tradingagents/research/onchain_replication/compact_features.py': '584268806ac6b6ea713737e4f54a6ba0bd923397165c089f2f359dfb3d916752', 'tradingagents/research/onchain_replication/compact_graph_artifacts.py': 'fd1395b0c274b1b51dc26365fd0c2954f904492cf77ddb3d553ce40c6dc6bf8a', 'tradingagents/research/onchain_replication/compact_matcher.py': '6a7e6e0c1918db7a42edc8fe8737f2b77497c0e32583c184e338e286fa47ad70', 'tradingagents/research/onchain_replication/compact_mcm.py': '6673fa484f37c0c3556c3d158035bb0c7f1db8f4a9f834ca50374c57c1e21b81', 'tradingagents/research/onchain_replication/compact_mcm_output.py': '4e31d1f241fc7c1f1ef4b7fc163d27a332ff057378a254e56667d2e7f6d29b11', 'tradingagents/research/onchain_replication/compact_mcm_publication.py': 'f32449d58b9bd3ecc71a6078cd0213fcb27217964de77964d74a41653b05d80a', 'tradingagents/research/onchain_replication/compact_native_features.py': '34a6f63125ac048df2d0f4a2b354ff2c6808ee8fc0dcc4b6a04bff1eeeb6e136', 'tradingagents/research/onchain_replication/compact_native_producer.py': '36cb548d012ee9a143fd65118d7540193406fd16002711b9f9e2899a9131d336', 'tradingagents/research/onchain_replication/compact_owner.py': 'c1f4f1b70ab5e955d5302cda5a1fd2dfc1c02a9df15589acabc7a36c80873171', 'tradingagents/research/onchain_replication/compact_pair_log.py': 'e7b38cbc4a0b13733e0018db897489acab5f7324368c7938addb20f8a9d2392d', 'tradingagents/research/onchain_replication/compact_policy.py': '4f4e4f91df881249540e8f7b0e33029f21e680bf7595fb0bbe075a8d8aee9d7d', 'tradingagents/research/onchain_replication/compact_publication.py': 'b2b999c40c38b286a6e24f319089998099306979da1e7d75b86d692b537216d8', 'tradingagents/research/onchain_replication/compact_sample_proof.py': 'cb94729af806f10b1c719cc240ec8c2546a1aa2a79591ef62cbf852c29256893', 'tradingagents/research/onchain_replication/compact_sampler.py': '7820254d9a9ac287e55b0d20d2c26e1907b625dd743e194fae0602110593a608', 'tradingagents/research/onchain_replication/compact_samples.py': 'f14a11212edd281901aab69fbe9b1164251988472baa65da6b319d50ff436d7b', 'tradingagents/research/onchain_replication/compact_stage.py': '3e35d200bcd04efa169ec64745ae54bb81ef1a58f3ae160157f00f40f60aad3e', 'tradingagents/research/onchain_replication/compact_terminal.py': 'b06ccedcfc6e3bb8356dec48fc2ea49092da2c1e18f23e32aeb8f58ca0e3c0b5', 'tradingagents/research/onchain_replication/compact_training.py': 'ef70263e79cf743aff6a389866a7fd86615b5bcdbd5b834ebe922ffd420bebd3', 'tradingagents/research/onchain_replication/comparison.py': 'b157f41b2b98517c67152209bac46fbedf3a2eb9471fd27f9c588a41e60c8c23', 'tradingagents/research/onchain_replication/component_store.py': 'ba0cf44dd7cf5af8c0b99cbe129f107ef7b40833a76b8162ae9d91512b566b68', 'tradingagents/research/onchain_replication/contracts.py': '3f88e9e56f2bfca059e2ef9da2b01ae593444b05e1067154653ea6a5479fea1a', 'tradingagents/research/onchain_replication/dataset.py': 'c8d701b5646395bb94e5037aefcc2d0d29a55de95cca05e019ce35d3f53561df', 'tradingagents/research/onchain_replication/dictionary.py': '32e27a4a17dc2aa993d1440d6486c75b0d4dcff341969dbf99bdff412dd7e446', 'tradingagents/research/onchain_replication/environment.py': '8b3d09acbce94502f58f5d595c0018e45e9854b8f04241705c50fb21051b8a28', 'tradingagents/research/onchain_replication/eth_source.py': '78e0731e16d2751534e3530dde7313e94950bd852f99b30cec4661dbf7db1487', 'tradingagents/research/onchain_replication/evaluation.py': 'e671f622101eced67b5807bb74f069bbc10cc45eec0c2f410157bd46399f33e2', 'tradingagents/research/onchain_replication/feature_journal.py': '00f157d8a2e0d1e1b8d657a7030ab1fe8e43bf4b113a1ca29288a5635d524665', 'tradingagents/research/onchain_replication/feature_pipeline.py': '19ebe96275095ded92743a1a1bcadc4178f85cd5d39f1ed23786fba279b5fa41', 'tradingagents/research/onchain_replication/feature_residency.py': '4ea5370958b65edf0d37950f12d358ab562291c786f28a287514c77c3838ddcd', 'tradingagents/research/onchain_replication/financial_execution.py': 'e16402d8625ed9b1c9fe5d308d18867b811b3acb2bb90b2e0bcb7132cd4a602e', 'tradingagents/research/onchain_replication/financial_wrapper_fixture.py': 'f4ea651b4677c83f8e16c316d17f704d44d9ec86ff78a4bf7c4b895e92e1a16e', 'tradingagents/research/onchain_replication/gat.py': 'c2292bb164869bb4202a2af028a453f547d8e2930cd9d58ee4a59ffcb72913d6', 'tradingagents/research/onchain_replication/graph_baselines.py': 'f284a85a0ce3aa5dee24c748c6a376d9d44a2d775409b874540215ff0e594907', 'tradingagents/research/onchain_replication/graph_production.py': 'ef5ee5e2c8f6438e4e334d1a468397ad6f60e176d157e7849b7132737c7c85e8', 'tradingagents/research/onchain_replication/graph_residency.py': '1ded72ad7c25135780a718455b430eafa020e8f3de6ca608b04e005b798609a6', 'tradingagents/research/onchain_replication/graph_store.py': 'dcea4265fab07e26fba1c94f56c3fb74b12d872a7378065ed6d4ae431e9e54bd', 'tradingagents/research/onchain_replication/hub_census_production.py': 'b9c406f19c32f2b78409b9a3260edebcad0ced042e9e4d187ff44e574d763d2a', 'tradingagents/research/onchain_replication/hub_edges.py': 'e5858170437f6d9f0a994315e2b2aa30d502844cf0a1c1b8ec782a1e693887e9', 'tradingagents/research/onchain_replication/import_metadata.py': '1c9455bc80b8f424bf63d6fdd5b94338ce54c14ead720990a2f787aef9e93dfe', 'tradingagents/research/onchain_replication/imported_mcm_identity.py': '8b062eaf6a9a4d7315591c3b1d96f3fd8de52fae873f4cf31769cf3224fcf5a1', 'tradingagents/research/onchain_replication/job.py': '755cbbc9f22a8d9718ebb53211135d08b62e485dd3edeca2fbec29998c43b923', 'tradingagents/research/onchain_replication/job_payload.py': 'c57db123a7c1a951a37656d5a19173e47fb71dcee62f87b69cbc58b8ec0069ea', 'tradingagents/research/onchain_replication/journal_recovery.py': '1f5a280789572a01d943e80081930e324e621127b742ef67b6d93b6041ed009d', 'tradingagents/research/onchain_replication/mapped_graph.py': 'c5e93b325599a82bf65e5b31074e9c76a73b25d479ddea7d3ff3687e75f7b197', 'tradingagents/research/onchain_replication/matching.py': 'e5a4cb7966a53522532158a13ef7293d4d081a26cffba56c2eb0761a628c72a6', 'tradingagents/research/onchain_replication/matching_ancestry.py': '51221522256e3f1babb03512a8dad4d293d12638c4579d4bddcf92945db5e4bc', 'tradingagents/research/onchain_replication/matching_annealing.py': '602636b8311431bd2f7d4d28ed59627e9ac576341b0dbcc6f0d41225dc79b7d1', 'tradingagents/research/onchain_replication/matching_checkpoint.py': '6ef36f12a8e601177c0dde507f99d80853df80ad46cfd7f0321e5c0d655ab9df', 'tradingagents/research/onchain_replication/matching_death.py': 'f76a96274e77d4f728d9d7e0b93db2a8bb4e663654ae59c0480f6c66192c3ff8', 'tradingagents/research/onchain_replication/matching_hardening.py': '3ed02e0df1508a7f963d3652cfea252b759c701235589ea5855cdd560e520f80', 'tradingagents/research/onchain_replication/matching_identity.py': 'f011658abf3b56b04a0ec33a7bdfed2c68e2e2e79791aa96c5ca7f8fd1653f89', 'tradingagents/research/onchain_replication/matching_owner.py': '22afd3f3a0c52221d43a2fa87d285db4874e08a21adf7c5ac336270e0ece0751', 'tradingagents/research/onchain_replication/matching_pair.py': '3fc8a0666b2b4bf334411a85decd7dbf484b038827255714c6727ffe3846621c', 'tradingagents/research/onchain_replication/matching_policy.py': '5d552673fb772f61344d212606a5d9d2c22c91c8de44dfa501d57422c9b4e739', 'tradingagents/research/onchain_replication/matching_reference.py': '75e3269a94cf0d840c299f52c7b138b58dd138251bde6048e52e6c1149934332', 'tradingagents/research/onchain_replication/matching_sparse.py': '06f2d312a1527f335decc8e0c4d1283448a28e783d5e64018d70e9bf3416883e', 'tradingagents/research/onchain_replication/mcm.py': 'd2527cdc34f1032f6ed9a3ff175fd1e7c21412e19e1d449ac53f773bd582f9df', 'tradingagents/research/onchain_replication/mcm_score_stream.py': '0cb6280571d465bcbd9b721492c5b6297666bbf14c5b5939cb36b4f9f72309fe', 'tradingagents/research/onchain_replication/metrics.py': '9476c2052e02be278c01360fa598a3a136a791ffaa90d90f1fde992c8a27c84b', 'tradingagents/research/onchain_replication/model.py': '2f55b04d3a707e212b2a1d9e0fb591eb3ec2b4828614edcc1a5a5d8f313d3b8e', 'tradingagents/research/onchain_replication/model_registry.py': '5a8be9dc05a1844528c1353cf2177185b4aa48cdc8a52581fdbb7acc5d910339', 'tradingagents/research/onchain_replication/native_producer.py': '5b7dff71ffe2b1e6c0570b859020d82af337d753665ae77cbea95ff07d1914ed', 'tradingagents/research/onchain_replication/native_reuse.py': 'a84274b035278fb5d840f58420cdc4d70eb7c5d8ca2ee5247392cf6bb29b2bbb', 'tradingagents/research/onchain_replication/neighborhood_census.py': 'be4704d1b19028c2ce734c35483986d6b49d7eecd6f6bd9048c96208b51c02a9', 'tradingagents/research/onchain_replication/neighborhood_policy.py': 'f86e19de0bedd4c12ef73fe2ba243990256f592c604c083d8e772ce8131bc12a', 'tradingagents/research/onchain_replication/neighborhoods.py': 'b53901125dc20dbb8a38b6e0e539866fb04109053afbcba0d75b2a2a8dc38271', 'tradingagents/research/onchain_replication/neural_authority.py': 'eed5f79f4c34819fb64ac2d79069ff56e4b24d175f2d391da9856f9d50186fb2', 'tradingagents/research/onchain_replication/neural_phases.py': '11af32f66fa1d9289c713da0304a5c7e0d6dd7a0623f783597bd0f9368988d71', 'tradingagents/research/onchain_replication/neural_physical.py': '8891e3ed52142f23ae987b8985cd4ee8e09caf86658623e43a37df7140dfe190', 'tradingagents/research/onchain_replication/neural_resource.py': 'ae7cd7ff76b0ddfd5e55645ea7a36a56d12089388add620a99fc70b1bc6759b9', 'tradingagents/research/onchain_replication/original_dictionary.py': 'cbe571a3758695b2ff63a45031c90840a7358538f9a2c0bad31077db8439a6d9', 'tradingagents/research/onchain_replication/original_import_preparation.py': 'cfae656ca4684271e5f9bc36f4ec4f09ff0da77436a5133b5f2a743c80ffe9e5', 'tradingagents/research/onchain_replication/original_import_stage.py': '7e1596c76e2af76eede19f5d9a6fd368c4f87eaf92156b4ac7be9def069d717a', 'tradingagents/research/onchain_replication/owned_io.py': '09d1fbcc03f2c9303db95f34ca6c07ddb47bfdb49b35452f4cb6829a5d667aeb', 'tradingagents/research/onchain_replication/parquet_ranges.py': '482c0686e552aae3157bf6cf12f802e0d284c68ce14d879000253b895450b044', 'tradingagents/research/onchain_replication/pooling.py': '054845bed22c44294ce41f2263155df0397c42b0b306755e36791ae5a3960303', 'tradingagents/research/onchain_replication/population_assembly.py': 'da65f5168c9d03cf8518f8dac1717482ff48c047ac451563f8728a7afe5c528f', 'tradingagents/research/onchain_replication/preservation.py': '2849670dcf847a97274cf590a2c6732cd7749e0e9e3e64e802cb2e415f08a410', 'tradingagents/research/onchain_replication/price_source.py': '66af531218352999667f2cac88c8393e70ddcf956b8e9f05db16a52c6b2f6e74', 'tradingagents/research/onchain_replication/prices.py': '5f44f1e689b614121c4b9cab5da75e17322074a9ec9f2a30a174ac353093798f', 'tradingagents/research/onchain_replication/provenance.py': 'd29f7f5c2fc5d0def6538d3a1eb13dc051c672d8ea38257af333930f87b9ff1b', 'tradingagents/research/onchain_replication/range_source.py': '5f1e004a89e2339d1f21c941415dc3976e9523f509a1d1591f23a8ea7a836bd7', 'tradingagents/research/onchain_replication/registered_features.py': '8a79c459336773bd139f377fe44fe1006796378651d30a8eb22c966c72f7b267', 'tradingagents/research/onchain_replication/replay.py': 'f9f016afad09ec5ec177a7fac04a0ca5d2fbb84262b06c6ea51e893e6b6433a0', 'tradingagents/research/onchain_replication/resource_binding.py': '06db541c97a122b911c91106daef524cd1e69a33c8a44b4d3abde77f7eb4fb5d', 'tradingagents/research/onchain_replication/resource_fixture.py': 'd92c0a92d877190f93f106ce505511ed59ceef050308fe5c32c29e13a7665028', 'tradingagents/research/onchain_replication/resources.py': 'e1d305e41938815d60ae2f465fcb2b543768c6862d176f4f6075ced53c8069c7', 'tradingagents/research/onchain_replication/restart_retention.py': '15e7b2090ce87081b0cd6e2338b4d62d348d779082947729cacf0210d3c6dc7d', 'tradingagents/research/onchain_replication/run.py': 'c61e67f749dbc133c16e2f6569846f8adf2242bfb9b1c1d86ec5f520bbbaf2d1', 'tradingagents/research/onchain_replication/sampling_policy.py': '79d1253009e6ba5e8815f82fdf3422113d5559b92e5e0e36bfec84fc2963354d', 'tradingagents/research/onchain_replication/sampling_weights.py': '5f1837f93fe0523d7c851654390584fc6c04fb803f2025fd027e74a5da8318d1', 'tradingagents/research/onchain_replication/score_batches.py': '4018ad121fcf7b6abf0ec93afe7b78857a1254611a02791965974437558c7a45', 'tradingagents/research/onchain_replication/score_tail.py': 'd18681b36e16bbca604346469d1cb79e14d2ebb1649108334c62356d9f6eb91e', 'tradingagents/research/onchain_replication/serialization.py': 'f711a0a931fe9fb91aadf0ad7ba6e68b638f3874e736790e05edd21acdefc65b', 'tradingagents/research/onchain_replication/source_footers.py': '65005ceca3072760befb09680f9c7aa469d5aaa5ab3f2af6a741d4ed2fef660e', 'tradingagents/research/onchain_replication/source_inventory.py': '6d868efe77d4d84af97fdb1657585ad86fda15866b44541f111656d3e09759db', 'tradingagents/research/onchain_replication/stage_retention.py': '2f608ba1735fd07fdf18eab8969854f61e9769603b84b16869a008cde108b478', 'tradingagents/research/onchain_replication/stage_retention_reader.py': 'c2ae559de8721bea87a3520d9d13591f6c47ee6cad9971c7166c2c63937736f5', 'tradingagents/research/onchain_replication/streamed_gat.py': 'e8355dc4443dc40b64fe2fd0d22f764d47280c655f921e9f1705042e348ec21f', 'tradingagents/research/onchain_replication/subsets.py': '59a17cb12711d8ec518f6f25ec4518f143647b79c3ef3286399dada114b7a22c', 'tradingagents/research/onchain_replication/temporal.py': 'd8adafb5a50716ce472848df05e8bbb804525ed8003958c7f9a25c82d81ad226', 'tradingagents/research/onchain_replication/training.py': '0e5ae299f48f21cde666d78319b7710208f6d959c0c2b1aea7e848f4252ff482', 'tradingagents/research/onchain_replication/verification.py': 'c492cc9be2eb0956035800c26bde5d6cc2999844cd7466eb151bd3ea82815873', 'tradingagents/research/onchain_replication/weekly.py': '079a427f212738759109b31da23933549a8b7751851e3033703cdd03dc5f054a', 'tradingagents/research/onchain_replication/workflow_storage.py': 'bf52b9408008ac3616f867ebef8130e2f315f8c8febf00ab1815557d68684554', 'tradingagents/research/verify.py': '3a45746a388307d1b375c885bb2fd7a22c2a60f139df714d2bbe98906d57d7eb'}
PREFIX='tradingagents/research/onchain_replication/'
PROGRAM='financial-wrapper-engineering-2026-10-03'
ROLE='operational_source_compatibility'
TRAINING='d5276b75491e130bd03d43de28120f72dd792e42af4446382a6c127d387b8ec0'
HELPER=PREFIX+'operational_source_compatibility.py'
FILE=4*1024**2
TOTAL=64*1024**2
PROOF_ROLES=('operational_source_compatibility_review','operational_source_compatibility_recovery')
class Unavailable(ValueError):pass
class CleanupFailure(RuntimeError):pass

def require(ok,why):
 if not ok:raise Unavailable(why)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(value):return type(value)is str and len(value)==64 and all(c in '0123456789abcdef' for c in value)
def relative(value):
 require(type(value)is str and value and not Path(value).is_absolute() and str(PurePosixPath(value))==value and '..' not in PurePosixPath(value).parts and value!='.','canonical relative metadata path required')
 return value

def _close(fd,primary):
 try:os.close(fd)
 except BaseException as error:
  fatal=lambda e:not isinstance(e,Exception) or isinstance(e,MemoryError)
  if primary is not None and fatal(primary):
   try:
    state=BaseException.__dict__['__dict__'].__get__(primary);prior=dict.get(state,'storage_cleanup_errors',())
    if type(prior)is not tuple:prior=(prior,)
    dict.__setitem__(state,'storage_cleanup_errors',prior+(error,))
   except BaseException as diagnostic:raise primary from diagnostic
   raise primary
  if fatal(error):raise error from primary
  failure=CleanupFailure('operational policy descriptor close uncertain');failure.storage_cleanup_errors=(error,);raise failure from primary

def _read(path,budget):
 path=Path(path);require(path.is_absolute() and path.resolve(strict=True)==path and len(path.parts)<=64,'canonical bounded evidence origin')
 require(time.monotonic()-budget['begun']<120,'finite operational evidence deadline')
 fds=[];primary=None
 try:
  fd=os.open('/',os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC);fds.append(fd)
  for part in path.parts[1:-1]:
   fd=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd);fds.append(fd)
  parent=fd;fd=os.open(path.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent);fds.append(fd)
  a=os.fstat(fd);require(stat.S_ISREG(a.st_mode) and 0<=a.st_size<=FILE,'bounded regular evidence')
  budget['bytes']+=a.st_size;require(budget['bytes']<=TOTAL,'aggregate evidence read limit')
  raw=bytearray()
  while True:
   require(time.monotonic()-budget['begun']<120,'finite operational evidence deadline')
   block=os.read(fd,min(1024**2,FILE+1-len(raw)))
   if not block:break
   raw.extend(block);require(len(raw)<=FILE,'evidence grew beyond bound')
  sig=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
  require(sig(a)==sig(os.fstat(fd))==sig(os.stat(path.name,dir_fd=parent,follow_symlinks=False))==sig(path.lstat()) and path.resolve(strict=True)==path and len(raw)==a.st_size,'evidence changed while read')
  return bytes(raw)
 except BaseException as error:primary=error;raise
 finally:
  selected=primary
  for fd in reversed(fds):
   try:_close(fd,selected)
   except BaseException as error:selected=error
  if selected is not primary:raise selected


def validate_maps(historical,target,helper_sha256):
 """Pure finite metadata predicate. Passing it confers no Run or policy authority."""
 require(type(historical)is dict and historical==OLD_MAP,'exact full historical194 path map')
 require(type(target)is dict and set(target)==set(OLD_MAP)|{HELPER} and digest(helper_sha256),'exact full target195 path map')
 require(all(type(k)is str and digest(v) for k,v in target.items()),'literal target path hashes')
 for path,pin in OLD_MAP.items():require(target[path]==CONTROL_TARGETS.get(path,pin),'unreviewed source path delta: '+path)
 require(target[HELPER]==helper_sha256,'exact registered compatibility checker')
 delta=[{'path':p,'old_sha256':historical.get(p),'new_sha256':target.get(p)} for p in sorted(set(historical)|set(target)) if historical.get(p)!=target.get(p)]
 require(len(delta)==4 and {x['path'] for x in delta}==set(CONTROL_TARGETS)|{HELPER},'finite nonreflexive exact operational delta')
 return delta

def validate_relation(historical,target,old,new):
 """Path maps authenticate each source-hash list; no list/set substitutions."""
 require(type(old)is dict and type(new)is dict and set(old)==set(new),'provenance schema/presence differs')
 require(old['source_commit']==HISTORICAL_SOURCE and type(new['source_commit'])is str and len(new['source_commit'])==40 and all(c in '0123456789abcdef' for c in new['source_commit']) and new['source_commit']!=HISTORICAL_SOURCE,'exact directional nonreflexive source edge')
 require(old['source_hashes']==sorted(set(historical.values())) and new['source_hashes']==sorted(set(target.values())),'each original/target source list must describe its own complete map')
 require({k:v for k,v in old.items() if k not in ('source_commit','source_hashes')}=={k:v for k,v in new.items() if k not in ('source_commit','source_hashes')},'non-source scientific provenance differs')


def validate_contract(policy,helper_sha):
 """Strict metadata only; a matching document is not independent authority."""
 require(type(policy)is dict and set(policy)=={'schema_version','kind','historical','target','allowed_delta','consumers','proof_roles'} and type(policy['schema_version'])is int and policy['schema_version']==1 and policy['kind']=='one-historical-parent-operational-source-edge-v1','strict prospective policy schema')
 require(policy['proof_roles']==list(PROOF_ROLES),'required exact independent proof roles')
 hist=policy['historical'];target=policy['target'];consumers=policy['consumers']
 require(set(hist)=={'identity','source','claim_sha256','failed_sha256','checkpoint_sha256','protocol_sha256','installed','closure_input','claim_input','failed_input','checkpoint_input','plan_input','job_input','provenance'},'historical policy schema')
 require(hist['identity']==HISTORICAL_ID and hist['source']==HISTORICAL_SOURCE and hist['claim_sha256']==HISTORICAL_CLAIM_SHA256 and hist['failed_sha256']==HISTORICAL_FAILED_SHA256 and hist['checkpoint_sha256']==HISTORICAL_CHECKPOINT_SHA256 and hist['protocol_sha256']==HISTORICAL_PROTOCOL_SHA256,'fixed historical identity/hash/protocol edge')
 require(set(target)=={'installed','closure_input'} and set(consumers)=={'complete100','continue100','predict'},'target/consumer schema')
 delta=validate_maps(hist['installed'],target['installed'],helper_sha)
 require(policy['allowed_delta']==delta,'exact full literal allowed delta')
 require(all(type(c)is dict and set(c)=={'experiment','cell_id'} and all(type(v)is str and v and '/' not in v and '..' not in v for v in c.values()) for c in consumers.values()),'future exact consumers unavailable')
 ids=[c['experiment'] for c in consumers.values()];require(len(set(ids))==3 and HISTORICAL_ID not in ids,'distinct future consumer identities')

 for name in ('closure_input','claim_input','failed_input','checkpoint_input','plan_input','job_input'):
  require(type(hist[name])is str and hist[name] and '/' not in hist[name] and '..' not in hist[name],'historical registered role unavailable')
 require(type(target['closure_input'])is str and target['closure_input'],'target closure role unavailable')
 require(type(hist['provenance'])is dict and hist['provenance'].get('source_commit')==HISTORICAL_SOURCE and hist['provenance'].get('source_hashes')==sorted(set(OLD_MAP.values())),'original full provenance unavailable')
 return policy

def _registered_unlocked(run,name,budget):
 """Private _reserve path: existing caller owns lifecycle._lock. Never reacquire."""
 info=run.admission.inputs.get(name)
 require(type(info)is dict and digest(info.get('sha256')),'genuine registered input pin unavailable')
 path=run.admission.root/relative(info['path']);raw=_read(path,budget)
 require(sha(raw)==info['sha256'],'registered input bytes differ')
 return raw

def _registered_normal(run,name,budget):
 # Perform finite bound check before original read_input (which performs its own
 # active/source/hash check under the genuine lifecycle lock).
 expected=_registered_unlocked(run,name,budget);raw=run.read_input(name)
 require(raw==expected,'genuine registered read changed')
 return raw

def _context(run,reader):
 from ..lifecycle import ResearchRun
 from ..admission import Admission
 from . import financial_wrapper_fixture as fixture
 require(type(run)is ResearchRun and type(run.admission)is Admission,'original genuine ResearchRun/Admission required')
 ad=run.admission
 require(ad.ready is True and ad.design_source==ad.source and ad.bindings is None and ad.bindings_sha256 is None,'genuine current source/design admission required')
 run._active();run._check_source()
 require(Path(__file__).resolve()==ad.root/HELPER and Path(fixture.__file__).resolve()==ad.root/(PREFIX+'financial_wrapper_fixture.py'),'actual compatibility/fixture source origin differs')
 budget={'begun':time.monotonic(),'bytes':0}
 def read(name):return reader(run,name,budget)
 require(ROLE in ad.inputs,'explicit registered operational compatibility input absent')
 raw=read(ROLE);policy=json.loads(raw)
 require(ad.experiment['source_files'].get(ad.inputs[ROLE]['path'])==sha(raw),'policy must be committed and source-pinned')
 helper_sha=sha(_read(Path(__file__),budget));validate_contract(policy,helper_sha)
 hist=policy['historical'];target=policy['target'];consumers=policy['consumers']
 require(ad.experiment['family']==FAMILY and ad.spec['program_id']==PROGRAM,'same original family required')
 job=json.loads(read('execution_job'));fixture.schema(job)
 plan=json.loads(read(job['payload']['plan_input']));fixture.validate_plan(plan)
 require(plan['phase'] in consumers and consumers[plan['phase']]=={'experiment':ad.experiment_id,'cell_id':plan['cell_id']} and plan['task']=='classification' and plan['execution']=='eager','exact prospective engineering consumer')
 require(ad.experiment['parent']==({'complete100':None,'continue100':HISTORICAL_ID,'predict':consumers['continue100']['experiment']}[plan['phase']]),'exact phase parent topology differs')
 require(plan['closure_input']==target['closure_input'],'target closure role mismatch')
 closure=json.loads(read(target['closure_input']));require(type(closure)is dict and set(closure)=={'schema_version','installed','scientific_model','scientific_training','candidate02'} and closure['schema_version']==1 and closure['candidate02']==fixture.CANDIDATE,'full target closure schema')
 require(closure['installed']==target['installed'] and closure['scientific_model']==MODEL and closure['scientific_training']==TRAINING,'target closure/science differs')
 require(sha(read(plan['model_input']))==MODEL and sha(read(plan['training_input']))==TRAINING,'original model/training bytes required')
 for path,pin in target['installed'].items():
  require(ad.experiment['source_files'].get(path)==pin and sha(_read(ad.root/relative(path),budget))==pin,'actual registered target body differs: '+path)
 for role in PROOF_ROLES:
  proof_raw=read(role);proof=json.loads(proof_raw)
  require(ad.experiment['source_files'].get(ad.inputs[role]['path'])==sha(proof_raw),'proof input not committed/source-pinned')
  require(set(proof)=={'schema_version','kind','policy_sha256','historical_map_sha256','target_map_sha256','checker_sha256','decision'} and proof['schema_version']==1 and proof['kind']==role and proof['decision']=='accepted','required actual independent evidence unavailable')
  require(proof['policy_sha256']==sha(raw) and proof['historical_map_sha256']==sha(canonical(hist['installed'])) and proof['target_map_sha256']==sha(canonical(target['installed'])) and proof['checker_sha256']==helper_sha,'independent proof exact source/policy pins differ')
 # A registered accepted-proof label is not independent authorship or external
 # recovery verification by this helper; those are Root release predicates.
 return policy,plan,read,budget,sha(raw)


def validate_current(run,plan,installed):
 policy,actual,read,budget,pin=_context(run,_registered_normal)
 require(actual==plan and installed==policy['target']['installed'],'authorized current plan/source map differs')
 return {'policy_sha256':pin,'qualification':'registered metadata consistency only; no external recovery or numerical authority'}


def _parent_predicate(run,old,new,checkpoint,reader):
 from ..verify import verify_claim
 policy,plan,read,budget,policy_sha=_context(run,reader);hist=policy['historical'];target=policy['target'];ad=run.admission
 require(plan['phase']=='continue100' and ad.experiment['parent']==HISTORICAL_ID and new['source_commit']==ad.source and new['cell_id']==plan['cell_id'],'current genuine continuation identity/source/cell differs')
 require(hist['provenance']==old,'policy must retain exact original complete provenance')
 validate_relation(hist['installed'],target['installed'],old,new)
 directory=ad.root/'research_runs'/HISTORICAL_ID;claim=verify_claim(directory)
 claim_raw=read(hist['claim_input']);failed_raw=read(hist['failed_input'])
 require(claim_raw==_read(directory/'claim.json',budget) and sha(claim_raw)==HISTORICAL_CLAIM_SHA256 and json.loads(claim_raw)==claim,'genuine historical claim bytes differ')
 require(failed_raw==_read(directory/'failed.json',budget) and sha(failed_raw)==HISTORICAL_FAILED_SHA256 and not (directory/'complete.json').exists(),'genuine permanently failed historical terminal differs')
 failed=json.loads(failed_raw);require(failed['status']=='failed' and failed['claim_sha256']==HISTORICAL_CLAIM_SHA256 and failed['experiment_id']==HISTORICAL_ID,'failed historical lifecycle joins')
 require(claim['source']==claim['design_source']==HISTORICAL_SOURCE and claim['experiment_id']==HISTORICAL_ID and claim['program_id']==PROGRAM and claim['experiment']['family']==FAMILY and claim['experiment']['charter']['sha256']==HISTORICAL_PROTOCOL_SHA256,'original source/design/program/protocol identity differs')
 require(all(claim['experiment']['source_files'].get(p)==h for p,h in hist['installed'].items()),'historical source map not bound to genuine old claim')
 oldjob_raw=read(hist['job_input']);oldjob=json.loads(oldjob_raw)
 from . import financial_wrapper_fixture as fixture
 fixture.schema(oldjob)
 require(sha(oldjob_raw)==claim['inputs']['execution_job']['sha256'],'exact original selected job')
 oldplan_raw=read(hist['plan_input']);oldplan=json.loads(oldplan_raw);fixture.validate_plan(oldplan)
 require(sha(oldplan_raw)==claim['inputs'][oldjob['payload']['plan_input']]['sha256'],'exact original job-selected plan')
 require(oldplan['phase']=='interrupt1' and oldplan['experiment']==HISTORICAL_ID and all(oldplan[k]==plan[k] for k in ('cell_id','task','execution')),'original interruption task/cell/backend differs')
 require(claim['experiment']['cells']==[plan['cell_id']],'original admitted fit cell')
 for key,pin in (('model_input',MODEL),('training_input',TRAINING),('recipe_input',old['input_hash'])):
  require(claim['inputs'][oldplan[key]]['sha256']==pin,'original scientific input hash differs')
 closure_raw=read(hist['closure_input']);closure=json.loads(closure_raw)
 require(sha(closure_raw)==claim['inputs'][oldplan['closure_input']]['sha256'] and closure['installed']==hist['installed'],'original path-complete historical closure differs')
 cp_raw=read(hist['checkpoint_input']);cp=ad.root/ad.inputs[hist['checkpoint_input']]['path']
 require(Path(checkpoint).resolve()==cp.resolve()==cp and sha(cp_raw)==HISTORICAL_CHECKPOINT_SHA256,'exact registered original checkpoint origin/hash')
 manifest=json.loads(cp_raw);require(manifest['provenance']==old and set(manifest['members'])=={'state.pt'} and manifest['members']['state.pt']=={'size':493424,'sha256':HISTORICAL_STATE_SHA256},'original checkpoint provenance/state manifest must remain unchanged')
 expected=ad.root/'research_artifacts'/'onchain_fit_cells'/sha(plan['cell_id'].encode())/HISTORICAL_ID
 require(cp.is_relative_to(expected/'checkpoints') and not (expected/'complete.json').exists() and (expected/'failed.json').is_file(),'original failed fit ancestry')
 # Recheck original failed-fit metadata at the held-lock boundary as well.
 prior=json.loads(read(plan['prior_input']))
 require(prior['parent']==HISTORICAL_ID and prior['provenance']==old and prior['checkpoint_input']==hist['checkpoint_input'],'original parent descriptor join')
 def original(role,path):
  body=read(prior[role]);require(ad.root/ad.inputs[prior[role]]['path']==path and body==_read(path,budget),'original failed-fit evidence origin differs')
  return json.loads(body)
 require(original('fit_claim_input',expected/'claim.json')=={'experiment_id':HISTORICAL_ID,'provenance':old,'parent_checkpoint':None},'original fresh interrupt fit claim')
 require(original('failed_fit_input',expected/'failed.json')=={'type':'PlannedInterruption','reason':'prospective engineering failed-parent fixture after one real update; no fit completion','last_checkpoint':str(cp)},'actual planned failed-fit terminal')
 diagnostic=ad.root/'research_artifacts/financial_wrapper_engineering'/oldplan['namespace']/'interrupted-checkpoint.json'
 require(original('diagnostic_input',diagnostic)=={'checkpoint':str(cp),'sha256':HISTORICAL_CHECKPOINT_SHA256,'provenance':old,'epochs_completed':1,'requires_genuine_failed_parent':True},'original interrupt diagnostic')
 require(original('schedule_input',expected/'schedule.json')=={'training':json.loads(read(plan['training_input'])),'seed':11,'task':plan['task'],'n_examples':16},'original complete schedule')
 for name,item in manifest['members'].items():
  path=cp.parent/name;rel=str(path.relative_to(ad.root));roles=[role for role,info in ad.inputs.items() if info['path']==rel and info['sha256']==item['sha256']]
  require(roles,'every original checkpoint member must be registered')
  body=read(roles[0]);require(len(body)==item['size'] and sha(body)==item['sha256'],'opaque original checkpoint member hash differs')
 return {'schema_version':1,'kind':'verified-operational-source-parent-edge-v1','policy_sha256':policy_sha,'historical_claim_sha256':HISTORICAL_CLAIM_SHA256,'historical_checkpoint_sha256':HISTORICAL_CHECKPOINT_SHA256,'historical_source':HISTORICAL_SOURCE,'target_source':ad.source,'historical_map_sha256':sha(canonical(hist['installed'])),'target_map_sha256':sha(canonical(target['installed'])),'historical_provenance_sha256':sha(canonical(old)),'target_provenance_sha256':sha(canonical(new)),'old_provenance_rewritten':False}


def require_parent_compatibility(run,old,new,checkpoint):
 return _parent_predicate(run,old,new,checkpoint,_registered_normal)


def _require_parent_under_fit_lock(run,old,new,checkpoint):
 """Internal training._reserve call while its original lifecycle lock is held.
 No caller boolean/token and no call to read_input/authorize/lock acquisition.
 """
 return _parent_predicate(run,old,new,checkpoint,_registered_unlocked)


def require_reference_policy(run,claim):
 policy,plan,read,budget,pin=_context(run,_registered_normal)
 require(plan['phase']=='continue100' and claim['experiment_id']==policy['consumers']['complete100']['experiment'],'exact prospective reference identity differs')
 require(claim['inputs'].get(ROLE,{}).get('sha256')==pin,'reference must have used identical prospective registered policy')
 require(all(claim['experiment']['source_files'].get(p)==h for p,h in policy['target']['installed'].items()),'reference target implementation differs')
 # The original wrapper already verifies actual COMPLETE claim/terminal and its
 # unchanged strict source/provenance equality before this supplementary check.
 return {'policy_sha256':pin,'reference_experiment':claim['experiment_id']}


def validate_prediction_parent(policy,policy_sha256,closure_sha256,parent_identity,parent_inputs,parent_sources,parent_cells):
 """Pure metadata predicate; it neither verifies nor creates a genuine claim.
 The runtime caller supplies fields from the original verified COMPLETE parent.
 """
 require(digest(policy_sha256) and digest(closure_sha256),'exact current policy/closure hashes unavailable')
 expected=policy['consumers']['continue100']
 require(parent_identity==expected['experiment'] and parent_cells==[expected['cell_id']],'prediction parent must be the fixed continuation consumer/cell')
 require(type(parent_inputs)is dict and parent_inputs.get(ROLE,{}).get('sha256')==policy_sha256,'completed parent used a different or missing compatibility policy')
 target=policy['target']
 require(parent_inputs.get(target['closure_input'],{}).get('sha256')==closure_sha256,'completed parent full implementation closure differs')
 require(type(parent_sources)is dict and all(parent_sources.get(p)==h for p,h in target['installed'].items()),'completed parent target implementation map differs')
 return {'policy_sha256':policy_sha256,'parent_experiment':parent_identity,'target_map_sha256':sha(canonical(target['installed']))}


def require_prediction_policy(run,claim):
 policy,plan,read,budget,pin=_context(run,_registered_normal)
 require(plan['phase']=='predict','prediction policy join is unavailable outside prediction')
 # financial_wrapper_fixture._parent already verified this exact claim and its
 # actual COMPLETE lifecycle, and preserved the strict scientific comparison.
 return validate_prediction_parent(policy,pin,sha(read(policy['target']['closure_input'])),claim['experiment_id'],claim['inputs'],claim['experiment']['source_files'],claim['experiment']['cells'])
