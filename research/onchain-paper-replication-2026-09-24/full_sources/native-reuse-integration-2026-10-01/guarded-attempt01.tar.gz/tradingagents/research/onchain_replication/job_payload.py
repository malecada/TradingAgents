"""Prepared component assembly inside one resource-guarded admitted job.

The source and population inputs must already be admitted. No automatic source
acquisition, mask repair or hidden representation fallback occurs during a fit.
"""
from dataclasses import asdict, fields
import json

from .contracts import Fold
from .dataset import Example, ExampleManifest, Scaler
from .provenance import canonical_bytes, freeze


def population_record(examples, scaler):
    return {'schema_version': 1,
        'examples': {'train': [asdict(x) for x in examples.train], 'test': [asdict(x) for x in examples.test],
            'exclusions': [dict(x) for x in examples.exclusions], 'train_hash': examples.train_hash,
            'test_mask_hash': examples.test_mask_hash, 'source_hashes': list(examples.source_hashes), 'fold_hash': examples.fold_hash},
        'scaler': asdict(scaler)}


def population_from_record(record):
    if set(record) != {'schema_version', 'examples', 'scaler'} or record['schema_version'] != 1:
        raise ValueError('population payload schema differs')
    source = record['examples']
    if set(source) != {f.name for f in fields(ExampleManifest)}:
        raise ValueError('example manifest fields differ')
    def example(row):
        if set(row) != {f.name for f in fields(Example)}:
            raise ValueError('example payload fields differ')
        return Example(**{k: tuple(v) if k in ('input_dates', 'input_prices', 'graph_hashes', 'graph_available_at') else v for k, v in row.items()})
    examples = ExampleManifest(tuple(map(example, source['train'])), tuple(map(example, source['test'])),
        tuple(freeze(x) for x in source['exclusions']), source['train_hash'], source['test_mask_hash'],
        tuple(source['source_hashes']), source['fold_hash'])
    scaler = Scaler(**{**record['scaler'], 'dates': tuple(record['scaler']['dates'])})
    return examples, scaler


def execute_fit_payload(run, payload, *, job_input='execution_job'):
    """Build/reuse registered fixed representations, then execute the batch."""
    from . import native_producer,native_reuse
    from .graph_store import load_graph
    from .registered_features import prepare_registered_features, reuse_registered_features
    from .run import execute_batch, preflight_batch
    from .feature_pipeline import representation_arm
    from .cache import cache_key
    from .feature_residency import read_feature_policy
    from .graph_residency import read_graph_policy,registered_graph_manifests,open_graph_population,GraphPopulationCleanupError
    registered = json.loads(run.read_input(job_input))
    if registered['kind'] != 'fit' or canonical_bytes(registered['payload']) != canonical_bytes(payload):
        raise ValueError('fit job payload differs from registration')
    # Validate execution policy before population production, graph loading or
    # numerical work. A missing caller reference must not bypass a planned policy.
    from .sampling_policy import read_sampling_policy,require_sampling_arm
    from .matching_policy import read_matching_policy,require_matching_arm
    from .neighborhood_policy import read_neighborhood_policy,require_neighborhood_arm
    native_routes={};native_reuses={}
    for representation,job in payload['representation_jobs'].items():
        native_reuses[representation]=native_reuse.selected(run,representation,job)
        native_routes[representation]=False if native_reuses[representation] else native_producer.selected(run,representation,job)
        neighborhood_input=job.get('neighborhood_input')
        matching_input=job.get('matching_input')
        sampling_input=job.get('sampling_input')
        graph_input=job.get('graph_residency_input')
        if job['operation']=='produce':
            producer=json.loads(run.read_input(job['plan_input']))['producers'][job['producer']]
            if producer.get('neighborhood_input')!=neighborhood_input:raise ValueError('producer neighborhood policy differs before fitting')
            if producer.get('matching_input')!=matching_input:raise ValueError('producer matching policy differs before fitting')
            if producer.get('sampling_input')!=sampling_input:raise ValueError('producer sampling policy differs before fitting')
            if producer.get('graph_residency_input')!=graph_input:raise ValueError('producer graph residency policy differs before fitting')
        elif sampling_input is not None:
            raise ValueError('sampling policy is unused for completed reuse')
        if job['operation']!='produce' and graph_input is not None:raise ValueError('graph residency policy unused for completed reuse')
        if job['operation']!='produce' and matching_input is not None:raise ValueError('matching policy unused for completed reuse')
        if job['operation']!='produce' and neighborhood_input is not None:raise ValueError('neighborhood policy unused for completed reuse')
        neighborhood=read_neighborhood_policy(run,neighborhood_input)
        require_neighborhood_arm(job['descriptor']['arm'],neighborhood)
        matching=read_matching_policy(run,matching_input)
        require_matching_arm(job['descriptor']['arm'],matching)
        read_graph_policy(run,graph_input)
        sampling=read_sampling_policy(run,sampling_input)
        require_sampling_arm(job['descriptor']['arm'],sampling)
    populations = {}
    for name, reference in payload['population_inputs'].items():
        if isinstance(reference, str):
            record = json.loads(run.read_input(reference))
        elif isinstance(reference, dict) and set(reference) == {'producer_input'}:
            from .population_assembly import produce_registered_population
            record = produce_registered_population(run, reference['producer_input'])['population']
        else:
            raise ValueError('invalid population input/producer reference')
        populations[name] = population_from_record(record)
    batch_plan = json.loads(run.read_input(payload['batch_plan_input']))
    if set(populations) != set(batch_plan['populations']):
        raise ValueError('job population membership differs from batch')
    if set(payload['representation_jobs']) != set(batch_plan['representations']):
        raise ValueError('job representation membership differs from batch')
    used = {item['representation'] for item in batch_plan['cells'] if item['status'] == 'ready' and item['representation'] is not None}
    if used != set(payload['representation_jobs']):
        raise ValueError('unreferenced representation computation forbidden')
    preflight_batch(run, populations, plan_input=payload['batch_plan_input'])
    for item in batch_plan['cells']:
        if item['status'] != 'ready' or item['representation'] is None:
            continue
        cell = item['cell']
        job = payload['representation_jobs'][item['representation']]
        descriptor = job['descriptor']
        examples, _ = populations[item['population']]
        required = sorted({h for row in (*examples.train, *examples.test) for h in row.graph_hashes})
        if descriptor['arm'] != representation_arm(cell['arm']) or descriptor['seed'] != cell['seed'] or descriptor['fold']['id'] != cell['fold'] or descriptor['fold']['member_hash'] != examples.fold_hash or descriptor['train_hash'] != examples.train_hash or descriptor['required_graphs'] != required or not set(required) <= set(descriptor['graph_population']):
            raise ValueError('representation job science differs from cell/population before fitting')
    for name, job in payload['representation_jobs'].items():
        reference = batch_plan['representations'][name]
        read_feature_policy(run,job.get('residency_input'))
        if 'output' not in reference or not reference.get('failure_output') or not {reference['output'], reference['failure_output']} <= set(run.admission.experiment['outputs']):
            raise ValueError('job binding/failure outputs must be registered before fitting')
        if job['operation'] == 'produce':
            source_examples, _ = populations[job['population']]
            required = sorted({h for row in (*source_examples.train, *source_examples.test) for h in row.graph_hashes})
            descriptor = job['descriptor']
            if source_examples.train_hash != descriptor['train_hash'] or source_examples.fold_hash != descriptor['fold']['member_hash'] or descriptor['required_graphs'] != required:
                raise ValueError('producer population differs from descriptor before fitting')
            producer = json.loads(run.read_input(job['plan_input']))['producers'][job['producer']]
            if producer.get('residency_input')!=job.get('residency_input'):raise ValueError('producer feature residency policy differs before fitting')
            if canonical_bytes(producer['descriptor']) != canonical_bytes(job['descriptor']) or producer['binding_output'] != reference['output'] or producer['journal_output'] not in run.admission.experiment['outputs']:
                raise ValueError('producer descriptor/output differs before fitting')
        elif job['operation'] == 'reuse':
            if native_reuses[name]:
                if job['binding_output']!=reference['output']:raise ValueError('native reuse binding output differs')
            else:run.read_input(job['journal_input'])
        else:
            raise ValueError('unknown representation operation before fitting')
    prepared = {}
    for name, job in payload['representation_jobs'].items():
        reference = batch_plan['representations'][name]
        if 'output' not in reference or not reference.get('failure_output'):
            raise ValueError('job representations require registered binding/failure outputs')
        try:
            descriptor = job['descriptor']
            if job['operation'] == 'reuse':
                if native_reuses[name]:
                    examples,scaler=populations[job['population']]
                    value=native_reuse.prepare(run,name,job,examples,scaler)
                else:
                    value = reuse_registered_features(run, job['journal_input'], descriptor,
                                                     max_array_bytes=job['max_array_bytes'],residency_input=job.get('residency_input'))
                run.write_json(reference['output'], value.binding)
            elif job['operation'] == 'produce':
                plan = json.loads(run.read_input(job['plan_input']))
                producer = plan['producers'][job['producer']]
                if canonical_bytes(producer['descriptor']) != canonical_bytes(descriptor) or producer['binding_output'] != reference['output']:
                    raise ValueError('job representation descriptor/output differs')
                examples, _ = populations[job['population']]
                def produce(graphs):
                    if native_routes[name]:
                        return native_producer.produce(run,name,job,graphs,examples)
                    return prepare_registered_features(run, job['producer'], graphs, examples,
                        Fold(**descriptor['fold']), descriptor['arm'], descriptor['seed'], descriptor['configs'],
                        plan_input=job['plan_input'], max_entries=producer['max_entries'],
                        max_array_bytes=producer['max_array_bytes'], continuation_input=job.get('continuation_input'),
                        residency_input=job.get('residency_input'),sampling_input=job.get('sampling_input'),
                        graph_residency_input=job.get('graph_residency_input'),matching_input=job.get('matching_input'),neighborhood_input=job.get('neighborhood_input'))
                graph_policy=read_graph_policy(run,job.get('graph_residency_input'))
                if graph_policy is not None:
                    manifests=registered_graph_manifests(run,producer)
                    with open_graph_population(manifests,graph_policy,max_graph_payload_bytes=job['max_graph_payload_bytes']) as population:
                        value,_=produce(population)
                else:
                    loader=(lambda path,sha:load_graph(path,sha,resident=True)) if native_routes[name] else load_graph
                    value=_produce_eager_graphs(run,descriptor,producer,job,produce,loader)
            else:
                raise ValueError('unknown representation operation')
            if value.binding['workflow_identity'] != cache_key(descriptor):
                raise ValueError('job representation workflow differs')
            run.write_json(reference['failure_output'], {'status': 'complete', 'representation': name,
                'reason': 'fixed representation available; no failure', 'workflow_identity': value.binding['workflow_identity']})
            prepared[name] = value
        except (GraphPopulationCleanupError,native_producer.NativeProducerCleanupError):
            # Cannot mark this merely unavailable and proceed with live maps.
            raise
        except (ValueError, RuntimeError, OSError) as error:
            reason = type(error).__name__+': '+str(error)
            # Completed numerical journals/partial outputs remain untouched.
            run.write_json(reference['failure_output'], {'status': 'failed', 'representation': name, 'reason': reason})
            if reference['output'] not in run._published_outputs:
                run.write_json(reference['output'], {'status': 'unavailable', 'reason': reason})
            if job['operation'] == 'produce':
                producer = json.loads(run.read_input(job['plan_input']))['producers'][job['producer']]
                if producer['journal_output'] not in run._published_outputs:
                    run.write_json(producer['journal_output'], {'status': 'unavailable', 'reason': reason})
    return execute_batch(run, populations, prepared, plan_input=payload['batch_plan_input'])


def _produce_eager_graphs(run,descriptor,producer,job,produce,load_graph):
    # Existing eager admission/loading remains the default path.
    manifests = []
    declared_bytes = 0
    for h in descriptor['graph_population']:
        graph_reference = producer['graphs'][h]
        if set(graph_reference) != {'input'}:
            raise ValueError('job graph loader requires admitted immutable graph input')
        input_name = graph_reference['input']
        metadata = json.loads(run.read_input(input_name))
        declared_bytes += sum(x['bytes'] for x in metadata['arrays'].values())
        info = run.admission.inputs[input_name]
        manifests.append((run.admission.root/info['path'], info['sha256']))
    if type(job['max_graph_payload_bytes']) is not int or not 0 < declared_bytes <= job['max_graph_payload_bytes']:
        raise ValueError('registered aggregate graph payload capacity exceeded; Python/temporary overhead needs outer guard')
    graphs = tuple(load_graph(path, sha) for path, sha in manifests)
    value,_=produce(graphs)
    return value
