Synthetic sum and count, fixed cells; no market experiment.
